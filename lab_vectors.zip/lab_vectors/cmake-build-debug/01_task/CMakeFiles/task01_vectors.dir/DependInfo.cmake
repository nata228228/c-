
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/Users/nataliamaslukova/CLionProjects/lab_vectors/01_task/main.cpp" "01_task/CMakeFiles/task01_vectors.dir/main.cpp.o" "gcc" "01_task/CMakeFiles/task01_vectors.dir/main.cpp.o.d"
  "/Users/nataliamaslukova/CLionProjects/lab_vectors/01_task/src/benchmark.cpp" "01_task/CMakeFiles/task01_vectors.dir/src/benchmark.cpp.o" "gcc" "01_task/CMakeFiles/task01_vectors.dir/src/benchmark.cpp.o.d"
  "/Users/nataliamaslukova/CLionProjects/lab_vectors/01_task/src/utils.cpp" "01_task/CMakeFiles/task01_vectors.dir/src/utils.cpp.o" "gcc" "01_task/CMakeFiles/task01_vectors.dir/src/utils.cpp.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")

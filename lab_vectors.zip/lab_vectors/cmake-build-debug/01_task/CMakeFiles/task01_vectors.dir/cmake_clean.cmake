file(REMOVE_RECURSE
  "CMakeFiles/task01_vectors.dir/main.cpp.o"
  "CMakeFiles/task01_vectors.dir/main.cpp.o.d"
  "CMakeFiles/task01_vectors.dir/src/benchmark.cpp.o"
  "CMakeFiles/task01_vectors.dir/src/benchmark.cpp.o.d"
  "CMakeFiles/task01_vectors.dir/src/utils.cpp.o"
  "CMakeFiles/task01_vectors.dir/src/utils.cpp.o.d"
  "task01_vectors"
  "task01_vectors.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/task01_vectors.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

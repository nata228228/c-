file(REMOVE_RECURSE
  "CMakeFiles/task02_deque.dir/main.cpp.o"
  "CMakeFiles/task02_deque.dir/main.cpp.o.d"
  "CMakeFiles/task02_deque.dir/src/benchmark.cpp.o"
  "CMakeFiles/task02_deque.dir/src/benchmark.cpp.o.d"
  "CMakeFiles/task02_deque.dir/src/utils.cpp.o"
  "CMakeFiles/task02_deque.dir/src/utils.cpp.o.d"
  "task02_deque"
  "task02_deque.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/task02_deque.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

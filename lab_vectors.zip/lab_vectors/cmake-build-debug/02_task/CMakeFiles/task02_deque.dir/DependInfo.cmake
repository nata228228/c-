
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/Users/nataliamaslukova/CLionProjects/lab_vectors/02_task/main.cpp" "02_task/CMakeFiles/task02_deque.dir/main.cpp.o" "gcc" "02_task/CMakeFiles/task02_deque.dir/main.cpp.o.d"
  "/Users/nataliamaslukova/CLionProjects/lab_vectors/02_task/src/benchmark.cpp" "02_task/CMakeFiles/task02_deque.dir/src/benchmark.cpp.o" "gcc" "02_task/CMakeFiles/task02_deque.dir/src/benchmark.cpp.o.d"
  "/Users/nataliamaslukova/CLionProjects/lab_vectors/02_task/src/utils.cpp" "02_task/CMakeFiles/task02_deque.dir/src/utils.cpp.o" "gcc" "02_task/CMakeFiles/task02_deque.dir/src/utils.cpp.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")

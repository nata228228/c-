#include "benchmark.h"
#include "utils.h"
#include <iostream>

std::vector<int> ordata;

int main() {
    ordata = generate_data(32768);
    register_deque_benchmarks();
    return 0;
}

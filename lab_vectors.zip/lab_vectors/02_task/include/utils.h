#ifndef DEQUE_UTILS_H
#define DEQUE_UTILS_H

#include <vector>
#include <string>

struct DequeResult {
    size_t N;
    long long time_ns;
    size_t size;
};

std::vector<int> generate_data(size_t max_size);
void write_deque_results(const std::string& filename, const std::vector<DequeResult>& results);

#endif

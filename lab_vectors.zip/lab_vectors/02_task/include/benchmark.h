#ifndef DEQUE_BENCHMARK_H
#define DEQUE_BENCHMARK_H

void register_deque_benchmarks();

#endif

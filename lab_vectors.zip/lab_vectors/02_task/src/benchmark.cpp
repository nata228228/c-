#include "benchmark.h"
#include "utils.h"
#include <benchmark/benchmark.h>
#include <deque>
#include <chrono>

extern std::vector<int> ordata;

std::vector<DequeResult> pushback_results;
std::vector<DequeResult> pushfront_results;
std::vector<DequeResult> randinsert_results;
std::vector<DequeResult> randerase_results;
std::vector<DequeResult> randaccess_results;

static void bm_pushback(benchmark::State& state) {
    size_t N = state.range(0);
    size_t final_size = 0;
    bool first = true;
    long long total_time = 0;
    
    for (auto _ : state) {
        std::deque<int> dq(ordata.begin(), ordata.begin() + N);
        
        auto start = std::chrono::high_resolution_clock::now();
        dq.push_back(42);
        auto end = std::chrono::high_resolution_clock::now();
        
        auto elapsed_seconds =std::chrono::duration_cast<std::chrono::nanoseconds>(end - start);
        total_time += elapsed_seconds.count();
        
        if (first) {
            final_size = dq.size();
            first = false;
        }
    }
    
    pushback_results.push_back({N, total_time / 5000, final_size});
}

static void bm_pushfront(benchmark::State& state) {
    size_t N = state.range(0);
    size_t final_size = 0;
    bool first = true;
    long long total_time = 0;
    
    for (auto _ : state) {
        std::deque<int> dq(ordata.begin(), ordata.begin() + N);
        
        auto start = std::chrono::high_resolution_clock::now();
        dq.push_front(42);
        auto end = std::chrono::high_resolution_clock::now();
        
        auto elapsed_seconds =std:: chrono:: duration_cast<std::chrono::nanoseconds>(end - start);
        total_time += elapsed_seconds.count();
        
        if (first) {
            final_size = dq.size();
            first = false;
        }
    }
    
    pushfront_results.push_back({N, total_time / 5000, final_size});
}

static void bm_randinsert(benchmark::State& state) {
    size_t N = state.range(0);
    size_t final_size = 0;
    bool first = true;
    long long total_time = 0;
    
    for (auto _ : state) {
        std::deque<int> dq(ordata.begin(), ordata.begin() + N);
        
        auto start = std::chrono::high_resolution_clock::now();
        dq.insert(dq.begin() + 9, 42);
        auto end = std::chrono::high_resolution_clock::now();
        
        auto elapsed_seconds =std:: chrono:: duration_cast<std::chrono::nanoseconds>(end - start);
        total_time += elapsed_seconds.count();

        if (first) {
            final_size = dq.size();
            first = false;
        }
    }
    
    randinsert_results.push_back({N, total_time / 5000, final_size});
}

static void bm_randerase(benchmark::State& state) {
    size_t N = state.range(0);
    size_t final_size = 0;
    bool first = true;
    long long total_time = 0;
    
    for (auto _ : state) {
        std::deque<int> dq(ordata.begin(), ordata.begin() + N);
        
        auto start = std::chrono::high_resolution_clock::now();
        dq.erase(dq.begin() + 9);
        auto end = std::chrono::high_resolution_clock::now();
        
        auto elapsed_seconds =std:: chrono:: duration_cast<std::chrono::nanoseconds>(end - start);
        total_time += elapsed_seconds.count();
        
        if (first) {
            final_size = dq.size();
            first = false;
        }
    }
    
    randerase_results.push_back({N, total_time / 5000, final_size});
}

static void bm_randaccess(benchmark::State& state) {
    size_t N = state.range(0);
    size_t final_size = 0;
    bool first = true;
    long long total_time = 0;
    
    for (auto _ : state) {
        std::deque<int> dq(ordata.begin(), ordata.begin() + N);
        
        auto start = std::chrono::high_resolution_clock::now();
        dq[9] = dq[9] + 1;
        auto end = std::chrono::high_resolution_clock::now();
        
        auto elapsed_seconds =std:: chrono:: duration_cast<std::chrono::nanoseconds>(end - start);
        total_time += elapsed_seconds.count();
        
        if (first) {
            final_size = dq.size();
            first = false;
        }
    }
    
    randaccess_results.push_back({N, total_time / 5000, final_size});
}

void register_deque_benchmarks() {
    std::vector<size_t> sizes = {256, 512, 1024, 2048, 4096, 8192, 16384, 32768};
    
    for (size_t N : sizes) {
        benchmark::RegisterBenchmark("pushback", bm_pushback)->Arg(N)->Iterations(5000);
        benchmark::RegisterBenchmark("pushfront", bm_pushfront)->Arg(N)->Iterations(5000);
        benchmark::RegisterBenchmark("randinsert", bm_randinsert)->Arg(N)->Iterations(5000);
        benchmark::RegisterBenchmark("randerase", bm_randerase)->Arg(N)->Iterations(5000);
        benchmark::RegisterBenchmark("randaccess", bm_randaccess)->Arg(N)->Iterations(5000);
    }
    
    benchmark::Initialize(nullptr, nullptr);
    benchmark::RunSpecifiedBenchmarks();

    write_deque_results("/Users/nataliamaslukova/CLionProjects/lab_vectors/02_task/results/deque_push_back.txt", pushback_results);
    write_deque_results("/Users/nataliamaslukova/CLionProjects/lab_vectors/02_task/results/deque_push_front.txt", pushfront_results);
    write_deque_results("/Users/nataliamaslukova/CLionProjects/lab_vectors/02_task/results/deque_random_insert.txt", randinsert_results);
    write_deque_results("/Users/nataliamaslukova/CLionProjects/lab_vectors/02_task/results/deque_random_erase.txt", randerase_results);
    write_deque_results("/Users/nataliamaslukova/CLionProjects/lab_vectors/02_task/results/deque_random_access.txt", randaccess_results);
}

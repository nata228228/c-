#ifndef UTILS_H
#define UTILS_H

#include <vector>
#include <string>

struct Result {
    size_t N;
    long long time_ns;
    size_t size;
    size_t capacity;
};

std::vector<int> generate_data(size_t max_size);
void write_results(const std::string& filename, const std::vector<Result>& results);

#endif

#ifndef BENCHMARK_H
#define BENCHMARK_H

void register_benchmarks();

#endif

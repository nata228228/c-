#include "utils.h"
#include <random>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <filesystem>

std::vector<int> generate_data(size_t max_size) {
    std::vector<int> data(max_size);
    std::mt19937 gen(12345);
    std::uniform_int_distribution<> dist(1, 1000);
    
    for (size_t i = 0; i < max_size; ++i) {
        data[i] = dist(gen);
    }
    return data;
}

void write_results(const std::string& filename, const std::vector<Result>& results) {
    size_t pos = filename.find_last_of('/');
    if (pos != std::string::npos) {
        std::filesystem::create_directories(filename.substr(0, pos));
    }
    
    std::ofstream file(filename);
    
    file << std::left << std::setw(8) << "N" 
         << std::setw(12) << "Time(ns)" 
         << std::setw(8) << "size" 
         << std::setw(10) << "capacity" << "\n";
    
    for (const auto& r : results) {
        file << std::left << std::setw(8) << r.N 
             << std::setw(12) << r.time_ns 
             << std::setw(8) << r.size 
             << std::setw(10) << r.capacity << "\n";
    }
    file.close();
}

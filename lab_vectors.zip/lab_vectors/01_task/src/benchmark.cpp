#include "benchmark.h"
#include "utils.h"
#include <benchmark/benchmark.h>
#include <vector>
#include <chrono>

extern std::vector<int> ordata;

std::vector<Result> pushback_results;
std::vector<Result> pushfront_results;
std::vector<Result> randinsert_results;
std::vector<Result> randerase_results;
std::vector<Result> randaccess_results;

static void bm_pushback(benchmark::State& state) {
    size_t N = state.range(0);
    size_t final_size = 0, final_capacity = 0;
    bool first = true;
    long long total_time = 0;
    
    for (auto _ : state) {
        std::vector<int> vec(ordata.begin(), ordata.begin() + N);
        
        auto start = std::chrono::high_resolution_clock::now();
        vec.push_back(42);
        auto end = std::chrono::high_resolution_clock::now();

        auto elapsed_seconds =std:: chrono:: duration_cast<std::chrono::nanoseconds>(end - start);
        total_time += elapsed_seconds.count();

        if (first) {
            final_size = vec.size();
            final_capacity = vec.capacity();
            first = false;
        }
    }
    
    pushback_results.push_back({N, total_time/ 1000, final_size, final_capacity});
}

static void bm_pushfront(benchmark::State& state) {
    size_t N = state.range(0);
    size_t final_size = 0, final_capacity = 0;
    bool first = true;
    long long total_time = 0;
    
    for (auto _ : state) {
        std::vector<int> vec(ordata.begin(), ordata.begin() + N);
        
        auto start = std::chrono::high_resolution_clock::now();
        vec.insert(vec.begin(), 42);
        auto end = std::chrono::high_resolution_clock::now();
        
        auto elapsed_seconds =std:: chrono:: duration_cast<std::chrono::nanoseconds>(end - start);
        total_time += elapsed_seconds.count();
        
        if (first) {
            final_size = vec.size();
            final_capacity = vec.capacity();
            first = false;
        }
    }
    
    pushfront_results.push_back({N, total_time / 1000, final_size, final_capacity});
}

static void bm_randinsert(benchmark::State& state) {
    size_t N = state.range(0);
    size_t final_size = 0, final_capacity = 0;
    bool first = true;
    long long total_time = 0;
    
    for (auto _ : state) {
        std::vector<int> vec(ordata.begin(), ordata.begin() + N);
        
        auto start = std::chrono::high_resolution_clock::now();
        vec.insert(vec.begin() + 9, 42);
        auto end = std::chrono::high_resolution_clock::now();
        
        auto elapsed_seconds =std:: chrono:: duration_cast<std::chrono::nanoseconds>(end - start);
        total_time += elapsed_seconds.count();
        
        if (first) {
            final_size = vec.size();
            final_capacity = vec.capacity();
            first = false;
        }
    }
    
    randinsert_results.push_back({N, total_time / 1000, final_size, final_capacity});
}

static void bm_randerase(benchmark::State& state) {
    size_t N = state.range(0);
    size_t final_size = 0, final_capacity = 0;
    bool first = true;
    long long total_time = 0;
    
    for (auto _ : state) {
        std::vector<int> vec(ordata.begin(), ordata.begin() + N);
        
        auto start = std::chrono::high_resolution_clock::now();
        vec.erase(vec.begin() + 9);
        auto end = std::chrono::high_resolution_clock::now();
        
        auto elapsed_seconds =std:: chrono:: duration_cast<std::chrono::nanoseconds>(end - start);
        total_time += elapsed_seconds.count();
        
        if (first) {
            final_size = vec.size();
            final_capacity = vec.capacity();
            first = false;
        }
    }
    
    randerase_results.push_back({N, total_time / 1000, final_size, final_capacity});
}

static void bm_randaccess(benchmark::State& state) {
    size_t N = state.range(0);
    size_t final_size = 0, final_capacity = 0;
    bool first = true;
    long long total_time = 0;
    
    for (auto _ : state) {
        std::vector<int> vec(ordata.begin(), ordata.begin() + N);
        
        auto start = std::chrono::high_resolution_clock::now();
        vec[9] = vec[9] + 1;
        auto end = std::chrono::high_resolution_clock::now();
        
        auto elapsed_seconds =std:: chrono:: duration_cast<std::chrono::nanoseconds>(end - start);
        total_time += elapsed_seconds.count();
        
        if (first) {
            final_size = vec.size();
            final_capacity = vec.capacity();
            first = false;
        }
    }
    
    randaccess_results.push_back({N, total_time / 1000, final_size, final_capacity});
}

void register_benchmarks() {
    std::vector<size_t> sizes = {256, 512, 1024, 2048, 4096, 8192, 16384, 32768};
    
    for (size_t N : sizes) {
        benchmark::RegisterBenchmark("pushback", bm_pushback)->Arg(N)->Iterations(5000);
        benchmark::RegisterBenchmark("pushfront", bm_pushfront)->Arg(N)->Iterations(5000);
        benchmark::RegisterBenchmark("randinsert", bm_randinsert)->Arg(N)->Iterations(5000);
        benchmark::RegisterBenchmark("randerase", bm_randerase)->Arg(N)->Iterations(5000);
        benchmark::RegisterBenchmark("randaccess", bm_randaccess)->Arg(N)->Iterations(5000);
    }
    
    benchmark::Initialize(nullptr, nullptr);
    benchmark::RunSpecifiedBenchmarks();
    

    write_results("/Users/nataliamaslukova/CLionProjects/lab_vectors/01_task/results/vector_push_back.txt", pushback_results);
    write_results("/Users/nataliamaslukova/CLionProjects/lab_vectors/01_task/results/vector_push_front.txt", pushfront_results);
    write_results("/Users/nataliamaslukova/CLionProjects/lab_vectors/01_task/results/vector_random_insert.txt", randinsert_results);
    write_results("/Users/nataliamaslukova/CLionProjects/lab_vectors/01_task/results/vector_random_erase.txt", randerase_results);
    write_results("/Users/nataliamaslukova/CLionProjects/lab_vectors/01_task/results/vector_random_access.txt", randaccess_results);
}

тут все раскидаю по фактам. все, что юзаю было так или этак блин\
что за сложности в этот раз вообшще :(\

struct были в конспекте!! да и по заданию нужны

void write_results(const std::string& filename, const std::vector<Result>& results) {
    size_t pos = filename.find_last_of('/'); //Ищет в пути к файлу последний слеш и записывает его инд в pos
    if (pos != std::string::npos) {
        std::filesystem::create_directories(filename.substr(0, pos));// ПРОСИЛИ СОЗДАТЬ ФАЙЛ. вот делаю. нашла такое, использую
        //filename.substr(0, pos) вот эта штука получает часть адреса до последнего слеша. ВОТ И ПОЛУЧИЛИ ПУТЬ
    }
так и было.


теперь про этот кусочек кода

    size_t N = state.range(0);
    size_t final_size = 0, final_capacity = 0;
    bool first = true;
    long long total_time = 0;

    for (auto _ : state) {
        std::vector<int> vec(ordata.begin(), ordata.begin() + N);

        auto start = std::chrono::high_resolution_clock::now();
        vec.push_back(42);
        auto end = std::chrono::high_resolution_clock::now();

        total_time += std::chrono::duration_cast<std::chrono::nanoseconds>(end - start).count();

        if (first) {
            final_size = vec.size();
            final_capacity = vec.capacity();
            first = false;
        }
    }

    большая часть--BM_ManualTiming(ручной подсчет короче), нашла этот метод,
     когда разбиралась с бенчмарком. Уточнила, он предпочтительный :))

     а вот этот if в конце просто, чтобы ток один раз записалась capacity и size ток один раз.




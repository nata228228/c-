#include "tracked_string.h"
#include <iostream>

int main() {
    TrackedString a("hello");
    TrackedString b("world");

    std::cout << a << " " << b << std::endl;

    auto c = a + b;
    std::cout << c << std::endl;

    return 0;
}
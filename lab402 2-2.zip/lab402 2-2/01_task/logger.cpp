#include "logger.h"
#include <iomanip>
#include <sstream>

Logger::Logger(const std::string& filename) : currentLevel(Level::INFO) {
    logFile.open(filename, std::ios::app);
}

Logger::~Logger() {
    logFile.close();
}

Logger& Logger::getInstance(const std::string& filename) {
    static Logger instance(filename);
    return instance;
}

void Logger::setLevel(int level) {
    currentLevel = level;
}

void Logger::log(const std::string& message, int level) {
    if (level > currentLevel) {
        return;
    }

    auto now = std::time(nullptr);
    auto tm = *std::localtime(&now);

    std::ostringstream timeStream;
    timeStream << std::put_time(&tm, "%Y-%m-%d %H:%M:%S");
    std::string timestamp = timeStream.str();

    std::string levelStr;
    switch (level) {
        case Level::ERROR:   levelStr = "ERROR"; break;
        case Level::WARNING: levelStr = "WARNING"; break;
        case Level::INFO:    levelStr = "INFO"; break;
        case Level::DEBUG:   levelStr = "DEBUG"; break;
    }

    logFile << "[" << timestamp << "] [" << levelStr << "] " << message << std::endl;
}
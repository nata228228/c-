#include "../01_task/logger.h"

int main() {
    auto& logger = Logger::getInstance("../../logs/task01.log");

    logger.setLevel(Level::INFO);
    logger.log("еррор", Level::ERROR);
    logger.log("ворнинг", Level::WARNING);
    logger.log("инфо", Level::INFO);
    logger.log("дебаг", Level::DEBUG);

    return 0;
}
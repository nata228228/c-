#ifndef LOGGER_H
#define LOGGER_H

#include <fstream>
#include <string>

struct Level {
    static const int ERROR = 0;
    static const int WARNING = 1;
    static const int INFO = 2;
    static const int DEBUG = 3;
};

class Logger {
    Logger(const std::string& filename);
    std::ofstream logFile;
    int currentLevel;

public:
    Logger(const Logger&) = delete;
    Logger& operator=(const Logger&) = delete;

    static Logger& getInstance(const std::string& filename);

    void setLevel(int level);

    void log(const std::string& message, int level);

    ~Logger();
};

#endif
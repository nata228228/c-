#include "tracked_string.h"
#include "../01_task/logger.h"
#include <sstream>

int TrackedString::counter = 0;

void TrackedString::logConstructor(const std::string& type, const TrackedString* other) {
    auto& logger = Logger::getInstance("../../logs/task04.log");

    std::ostringstream oss;
    oss << "[" << type << "] id=" << id
        << " this=" << static_cast<const void*>(this);

    if (other != nullptr) {
        oss << " from id=" << other->id;
    }

    logger.log(oss.str(), Level::INFO);
}

TrackedString::TrackedString() : TrackedString("") {
}

TrackedString::TrackedString(const char* str) : TrackedString(std::string(str ? str : "")) {
}

TrackedString::TrackedString(const std::string& str) : value(str), id(++counter) {
    logConstructor("string ctor");
}

TrackedString::TrackedString(const TrackedString& other)
    : value(other.value), id(++counter) {
    logConstructor("copy ctor", &other);
}

TrackedString& TrackedString::operator=(const TrackedString& other) {
    if (this == &other) {
        auto& logger = Logger::getInstance("../../logs/task04.log");
        std::ostringstream oss;
        oss << "[self-assignment] id=" << id
            << " this=" << static_cast<const void*>(this);
        logger.log(oss.str(), Level::INFO);
        return *this;
    }

    value = other.value;
    logConstructor("copy assignment", &other);
    return *this;
}

TrackedString::~TrackedString() {
    auto& logger = Logger::getInstance("../../logs/task04.log");

    std::ostringstream oss;
    oss << "[destructor] id=" << id
        << " this=" << static_cast<const void*>(this);

    logger.log(oss.str(), Level::INFO);
}
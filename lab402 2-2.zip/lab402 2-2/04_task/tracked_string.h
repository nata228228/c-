#ifndef TRACKED_STRING_H
#define TRACKED_STRING_H

#include <string>
#include "../01_task/logger.h"

class TrackedString {
    std::string value;
    static int counter;
    int id;

    void logConstructor(const std::string& type, const TrackedString* other = nullptr);

public:
    TrackedString();
    TrackedString(const char* str);
    TrackedString(const std::string& str);
    TrackedString(const TrackedString& other);
    TrackedString& operator=(const TrackedString& other);

    ~TrackedString();

    const std::string& getValue() const { return value; }
    int getId() const { return id; }
};

#endif
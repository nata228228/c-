#include "tracked_string.h"

int main() {
    TrackedString x;
    TrackedString y("test");

    return 0;
}
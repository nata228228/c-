#ifndef WRAPPER_H
#define WRAPPER_H

#include <string>
#include "tracked_string.h"

class Wrapper {
    TrackedString str;
public:
    Wrapper(const std::string& s);
    ~Wrapper();

};

#endif
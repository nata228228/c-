#include "wrapper.h"
#include "../01_task/logger.h"

Wrapper::Wrapper(const std::string& s) {
    str = TrackedString(s);
}


// Wrapper::Wrapper(const std::string& s) : str(s) {
// }


Wrapper::~Wrapper() {}
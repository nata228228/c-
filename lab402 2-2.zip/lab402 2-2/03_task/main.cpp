#include "wrapper.h"
#include "../01_task/logger.h"
#include <iostream>

int main() {
    auto& logger = Logger::getInstance("../../logs/task03_a.log");
    // auto& logger = Logger::getInstance("../../logs/task03_b.log");
    // logger.setLevel(Level::INFO);

    std::cout << "Вариант А" << std::endl;
    logger.log("start ", Level::INFO);


    // std::cout << "Вариант Б" << std::endl;
    // logger.log("start ", Level::INFO);


    Wrapper w("for t_str");



    return 0;
}
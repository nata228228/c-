#include "tracked_string.h"
#include "../01_task/logger.h"
#include <iostream>

int main() {
    auto& logger = Logger::getInstance("../../logs/task02.log");
    logger.setLevel(Level::DEBUG);

    TrackedString a;
    TrackedString b("hello");
    std::string s = "world";
    TrackedString c(s);
    TrackedString d = c;
    
    return 0;
}

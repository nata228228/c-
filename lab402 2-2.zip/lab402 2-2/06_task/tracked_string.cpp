#include "tracked_string.h"
#include "../01_task/logger.h"
#include <sstream>

int TrackedString::counter = 0;

void TrackedString::logConstructor(const std::string& type, const TrackedString* other) {
    auto& logger = Logger::getInstance("../../logs/task06.log");

    std::ostringstream oss;
    oss << "[" << type << "] id=" << id
        << " this=" << static_cast<const void*>(this);

    if (other != nullptr) {
        oss << " from id=" << other->id;
    }

    logger.log(oss.str(), Level::INFO);
}

TrackedString::TrackedString() : TrackedString("") {
}

TrackedString::TrackedString(const char* str) : TrackedString(std::string(str ? str : "")) {
}

TrackedString::TrackedString(const std::string& str) : value(str), id(++counter) {
    logConstructor("string ctor");
}

TrackedString::TrackedString(const TrackedString& other)
    : value(other.value), id(++counter) {
    logConstructor("copy ctor", &other);
}

TrackedString& TrackedString::operator=(const TrackedString& other) {
    if (this == &other) {
        auto& logger = Logger::getInstance("../../logs/task06.log");
        std::ostringstream oss;
        oss << "[self-assignment] id=" << id
            << " this=" << static_cast<const void*>(this);
        logger.log(oss.str(), Level::INFO);
        return *this;
    }

    value = other.value;
    logConstructor("copy assignment", &other);
    return *this;
}

TrackedString::~TrackedString() {
    auto& logger = Logger::getInstance("../../logs/task06.log");

    std::ostringstream oss;
    oss << "[destructor] id=" << id
        << " this=" << static_cast<const void*>(this);

    logger.log(oss.str(), Level::INFO);
}



std::ostream& operator<<(std::ostream& os, const TrackedString& ts) {
    auto& logger = Logger::getInstance("../../logs/task06.log");
    logger.log("[operator<<] ", Level::INFO);

    os << ts.value;
    return os;
}

 bool operator==(const TrackedString& a, const TrackedString& b) {
    auto& logger = Logger::getInstance("../../logs/task06.log");
    logger.log("[operator==] ", Level::INFO);

    return a.value == b.value;
}


bool operator!=(const TrackedString& a, const TrackedString& b) {
    auto& logger = Logger::getInstance("../../logs/task06.log");
    logger.log("[operator!=] ", Level::INFO);

    return !(a == b);
}

bool operator<(const TrackedString& a, const TrackedString& b) {
    auto& logger = Logger::getInstance("../../logs/task06.log");
    logger.log("[operator<] ", Level::INFO);

    return a.value < b.value;
}

TrackedString operator+(const TrackedString& a, const TrackedString& b) {
    auto& logger = Logger::getInstance("../../logs/task06.log");
    logger.log("[operator+] ", Level::INFO);

    return TrackedString(a.value + b.value);
}
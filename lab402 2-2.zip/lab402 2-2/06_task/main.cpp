#include "tracked_string.h"
#include "../01_task/logger.h"
#include <iostream>
#include <vector>

int main() {
    auto& logger = Logger::getInstance("../../logs/task06.log");
    logger.setLevel(Level::DEBUG);
    
    logger.log("6 задание ",Level::INFO);
    
    std::vector<TrackedString> vec;
    
    vec.push_back(TrackedString("temp"));
    TrackedString ts("str");
    vec.push_back(ts);
    vec.emplace_back("temp");
    vec.emplace_back(TrackedString("temp"));
    
    return 0;
}

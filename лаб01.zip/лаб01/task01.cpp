#include <iostream>
#include <cstdint>

void print_bits(int32_t x) {
    for (int i = 31; i >= 0; --i) {
        std::cout << ((x >> i) & 1);
    }
    std::cout<<" = " << (int)x;
}

int main() {
    std::cout << "задание 1"<<'\n';
    int a, b;
    a=42;
    b=-17;
    print_bits(a);
    std::cout << '\n';
    print_bits(b);
    std::cout << '\n'<<"-------------------------------------"<<'\n';
    int result1 = a & b;
    print_bits(result1);
    std::cout << '\n';
    std::cout << "a & b = " << result1 <<'\n'<<'\n'<< '\n';

    print_bits(a);
    std::cout << '\n';
    print_bits(b);
    std::cout << '\n'<<"-------------------------------------"<<'\n';
    int result2 = a | b;
    print_bits(result2);
    std::cout << '\n';
    std::cout << "a | b = " << result2<<'\n'<<'\n'<< '\n';

    print_bits(a);
    std::cout << '\n';
    print_bits(b);
    std::cout << '\n'<<"-------------------------------------"<<'\n';
    int result3 = a ^ b;
    print_bits(result3);
    std::cout << '\n';
    std::cout << "a ^ b = " << result3 <<'\n'<<'\n'<<'\n';

    print_bits(a);
    std::cout << '\n';
    std::cout <<"-------------------------------------"<<'\n';
    int result4 = ~a;
    print_bits(result4);
    std::cout << '\n';
    std::cout << "~a = " << result4 <<'\n'<<'\n'<< '\n';

    print_bits(a);
    std::cout << '\n';
    std::cout <<"-------------------------------------"<<'\n';
    int result5 = a>>2;
    int result52 = a<<2;
    print_bits(result5);
    std::cout <<'\n';

    print_bits(result52);

    std::cout << '\n';
    std::cout << "a>>2 = " << result5 <<'\n'<<"a<<2 = " << result52 <<'\n'<<'\n'<< '\n';

    print_bits(b);
    std::cout << '\n';
    std::cout <<"-------------------------------------"<<'\n';
    int result6 = b>>2;
    int result62 = b<<2;
    print_bits(result6);
    std::cout<<'\n';

    print_bits(result62);

    std::cout << '\n';
    std::cout << "b>>2 = " << result6 <<'\n'<<"b<<2 = " << result62 <<'\n'<<'\n'<< '\n';

}
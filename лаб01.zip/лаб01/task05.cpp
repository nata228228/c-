#include <iostream>
#include <chrono>
#include <iomanip>

template<typename T>
void da_rabbit_loop(T& x, size_t N) {   //благодаря
    for (size_t i = 0; i < N; ++i) {    // & квалификатор volatile сохраняется.
        x += 1;                         // Если бы было T x , volatile был бы отброшен
    }
}



void row(std::string(type), int size_bytes, double time_microseconds) {
    std::cout << "| " << std::setw(15) << std::left << type
              << " | " << std::setw(14) << std::right << size_bytes
              << " | " << std::setw(20) << std::right << time_microseconds << " |\n";
}

int main() {
    const size_t N = 100000000;

    std::cout << "Таблица 1: С volatile\n";
    std::cout << "-----------------------------------------------------------\n";
    std::cout << "| Тип             | Размер (байт)  | Время                |\n";
    std::cout << "-----------------------------------------------------------\n";



    //char v
    {
        volatile char x = 0;
        auto start = std::chrono::high_resolution_clock::now();
        da_rabbit_loop(x, N);
        auto end = std::chrono::high_resolution_clock::now();
        auto time = std::chrono::duration<double, std::micro>(end - start).count();

        row("char", sizeof(char), time);

    }

    // short v
    {
        volatile short x = 0;
        auto start = std::chrono::high_resolution_clock::now();
        da_rabbit_loop(x, N);
        auto end = std::chrono::high_resolution_clock::now();
        auto time = std::chrono::duration<double, std::micro>(end - start).count();

        row("short", sizeof(short), time);
    }

    //int v
    {
        volatile int x = 0;
        auto start = std::chrono::high_resolution_clock::now();
        da_rabbit_loop(x, N);
        auto end = std::chrono::high_resolution_clock::now();
        auto time = std::chrono::duration<double, std::micro>(end - start).count();

        row("int", sizeof(int), time);
    }

    // uchar v
    {
        volatile unsigned char x = 0;
        auto start = std::chrono::high_resolution_clock::now();
        da_rabbit_loop(x, N);
        auto end = std::chrono::high_resolution_clock::now();
        auto time = std::chrono::duration<double, std::micro>(end - start).count();

        row("unsigned char", sizeof(unsigned char), time);
    }

    // ushort v
    {
        volatile unsigned short x = 0;
        auto start = std::chrono::high_resolution_clock::now();
        da_rabbit_loop(x, N);
        auto end = std::chrono::high_resolution_clock::now();
        auto time = std::chrono::duration<double, std::micro>(end - start).count();

        row("unsigned short", sizeof(unsigned short), time);
    }

    // uint v
    {
        volatile unsigned int x = 0;
        auto start = std::chrono::high_resolution_clock::now();
        da_rabbit_loop(x, N);
        auto end = std::chrono::high_resolution_clock::now();
        auto time = std::chrono::duration<double, std::micro>(end - start).count();

        row("unsigned int", sizeof(unsigned int), time);
    }

    // float v
    {
        volatile float x = 0.0f;
        auto start = std::chrono::high_resolution_clock::now();
        da_rabbit_loop(x, N);
        auto end = std::chrono::high_resolution_clock::now();
        auto time = std::chrono::duration<double, std::micro>(end - start).count();

        row("float", sizeof(float), time);
    }

    // d v
    {
        volatile double x = 0.0;
        auto start = std::chrono::high_resolution_clock::now();
        da_rabbit_loop(x, N);
        auto end = std::chrono::high_resolution_clock::now();
        auto time = std::chrono::duration<double, std::micro>(end - start).count();

        row("double", sizeof(double), time);
    }

    std::cout << "-----------------------------------------------------------\n\n";

    // без volatile

    std::cout << "Таблица 2: Без volatile\n";
    std::cout << "-----------------------------------------------------------\n";
    std::cout << "| Тип             | Размер (байт)  | Время                |\n";
    std::cout << "-----------------------------------------------------------\n";

    // char
    {
        char x = 0;
        auto start = std::chrono::high_resolution_clock::now();
        da_rabbit_loop(x, N);
        auto end = std::chrono::high_resolution_clock::now();
        auto time = std::chrono::duration<double, std::micro>(end - start).count();

        row("char", sizeof(char), time);
    }

    // short
    {
        short x = 0;
        auto start = std::chrono::high_resolution_clock::now();
        da_rabbit_loop(x, N);
        auto end = std::chrono::high_resolution_clock::now();
        auto time = std::chrono::duration<double, std::micro>(end - start).count();

        row("short", sizeof(short), time);
    }

    //int
    {
        int x = 0;
        auto start = std::chrono::high_resolution_clock::now();
        da_rabbit_loop(x, N);
        auto end = std::chrono::high_resolution_clock::now();
        auto time = std::chrono::duration<double, std::micro>(end - start).count();

        row("int", sizeof(int), time);
    }

    //  uchar
    {
        unsigned char x = 0;
        auto start = std::chrono::high_resolution_clock::now();
        da_rabbit_loop(x, N);
        auto end = std::chrono::high_resolution_clock::now();
        auto time = std::chrono::duration<double, std::micro>(end - start).count();

        row("unsigned char", sizeof(unsigned char), time);
    }

    // ushort
    {
        unsigned short x = 0;
        auto start = std::chrono::high_resolution_clock::now();
        da_rabbit_loop(x, N);
        auto end = std::chrono::high_resolution_clock::now();
        auto time = std::chrono::duration<double, std::micro>(end - start).count();

        row("unsigned short", sizeof(unsigned short), time);
    }

    // uint
    {
        unsigned int x = 0;
        auto start = std::chrono::high_resolution_clock::now();
        da_rabbit_loop(x, N);
        auto end = std::chrono::high_resolution_clock::now();
        auto time = std::chrono::duration<double, std::micro>(end - start).count();

        row("unsigned int", sizeof(unsigned int), time);
    }

    // float
    {
        float x = 0.0f;
        auto start = std::chrono::high_resolution_clock::now();
        da_rabbit_loop(x, N);
        auto end = std::chrono::high_resolution_clock::now();
        auto time = std::chrono::duration<double, std::micro>(end - start).count();

        row("float", sizeof(float), time);
    }

    // d
    {
        double x = 0.0;
        auto start = std::chrono::high_resolution_clock::now();
        da_rabbit_loop(x, N);
        auto end = std::chrono::high_resolution_clock::now();
        auto time = std::chrono::duration<double, std::micro>(end - start).count();

        row("double", sizeof(double), time);
    }

    std::cout << "-----------------------------------------------------------\n\n";
    return 0;
}
#include <iostream>
#include <chrono>
#include <cstdint>
#include <iomanip>

void row(std::string(type), std::string(name), double a_1, double a_2) {
    std::cout << "| " << std::setw(8) << std::left << type << " "
              << "| " << std::setw(23) << std::left << name << " "
              << "| " << std::setw(24) << std::right << a_1 << " "
              << "| " << std::setw(20) << std::right << a_2 << " |\n";
}

int main() {
    const size_t N = 100000000;
    std::cout << "-----------------------------------------------------------------------------\n";
    std::cout << "| Тип      | Операция       | Арифметика (время)       | Битовая (время)    |\n";
    std::cout << "-----------------------------------------------------------------------------\n";

    volatile int32_t x = 123456789;
    volatile uint32_t x_unsigned = 123456789U;
    volatile int dva = 2;

    {
        // делим на 2
        auto start = std::chrono::high_resolution_clock::now();
        for (size_t i = 0; i < N; ++i) {
            x = 123456789;
            x = x / dva; }
        auto end = std::chrono::high_resolution_clock::now();
        auto time_del2_1 = std::chrono::duration<double, std::micro>(end - start);

        start = std::chrono::high_resolution_clock::now();
        for (size_t i = 0; i < N; ++i) {
            x = 123456789;
            x = x >> 1;
        }
        end = std::chrono::high_resolution_clock::now();
        auto time_del2_2 = std::chrono::duration<double, std::micro>(end - start);

        row("int32_t", "Деление на 2", time_del2_1.count(), time_del2_2.count());
    }

    {
        // * 2
        auto start = std::chrono::high_resolution_clock::now();
        for (size_t i = 0; i < N; ++i) {
            x = 123456789;
            x = x * dva;
        }
        auto end = std::chrono::high_resolution_clock::now();
        auto time_del2_1 = std::chrono::duration<double, std::micro>(end - start).count();

        start = std::chrono::high_resolution_clock::now();
        for (size_t i = 0; i < N; ++i) {
            x = 123456789;
            x = x << 1;
        }
        end = std::chrono::high_resolution_clock::now();
        auto time_del2_2 = std::chrono::duration<double, std::micro>(end - start).count();

        row("int32_t", "Умножение на 2", time_del2_1, time_del2_2);
    }

    {
        // чет
        auto start = std::chrono::high_resolution_clock::now();
        for (size_t i = 0; i < N; ++i) {
            x = 123456789;
            volatile bool r = (x % dva == 0);
        }
        auto end = std::chrono::high_resolution_clock::now();
        auto time_del2_1 = std::chrono::duration<double, std::micro>(end - start).count();

        start = std::chrono::high_resolution_clock::now();
        for (size_t i = 0; i < N; ++i) { x = 123456789;
            volatile bool r = ((x & 1) == 0);
        }
        end = std::chrono::high_resolution_clock::now();
        auto time_del2_2 = std::chrono::duration<double, std::micro>(end - start).count();

        row("int32_t", "Четность", time_del2_1, time_del2_2);
    }

    // теперь беззнак

    {
        // делим на 2
        auto start = std::chrono::high_resolution_clock::now();
        for (size_t i = 0; i < N; ++i) {
            x = 123456789U;
            x = x / dva; }
        auto end = std::chrono::high_resolution_clock::now();
        auto time_del2_1 = std::chrono::duration<double, std::micro>(end - start).count();

        start = std::chrono::high_resolution_clock::now();
        for (size_t i = 0; i < N; ++i) {
            x = 123456789U;
            x = x >> 1; }
        end = std::chrono::high_resolution_clock::now();
        auto time_del2_2 = std::chrono::duration<double, std::micro>(end - start).count();

        row("uint32_t", "Деление на 2", time_del2_1, time_del2_2);
    }

    {
        // * на 2
        auto start = std::chrono::high_resolution_clock::now();
        for (size_t i = 0; i < N; ++i) {
            x = 123456789U;
            x = x * dva; }
        auto end = std::chrono::high_resolution_clock::now();
        auto time_del2_1 = std::chrono::duration<double, std::micro>(end - start).count();

        start = std::chrono::high_resolution_clock::now();
        for (size_t i = 0; i < N; ++i) {
            x = 123456789U;
            x = x << 1;
        }
        end = std::chrono::high_resolution_clock::now();
        auto time_del2_2 = std::chrono::duration<double, std::micro>(end - start).count();

        row("uint32_t", "Умножение на 2", time_del2_1, time_del2_2);
    }

    {
        // чет
        auto start = std::chrono::high_resolution_clock::now();
        for (size_t i = 0; i < N; ++i) {
            x = 123456789U;
            volatile bool r = (x % dva == 0); }
        auto end = std::chrono::high_resolution_clock::now();
        auto time_del2_1 = std::chrono::duration<double, std::micro>(end - start).count();

        start = std::chrono::high_resolution_clock::now();
        for (size_t i = 0; i < N; ++i) {
            x = 123456789U;
            volatile bool r = ((x & 1) == 0);
        }
        end = std::chrono::high_resolution_clock::now();
        auto time_del2_2 = std::chrono::duration<double, std::micro>(end - start).count();

        row("uint32_t", "Чётность", time_del2_1, time_del2_2);
    }

    std::cout << "+----------+------------------+------------------------+--------------------+\n";

    return 0;
}
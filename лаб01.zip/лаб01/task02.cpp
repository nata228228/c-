#include <iostream>

void print_bits(int32_t x) {
    for (int i = 31; i >= 0; --i) {
        std::cout << ((x >> i) & 1);
    }
}

int main() {

    std::cout << '\n'<< "Задание 2"<<'\n'<< '\n';

    std::cout << "беззнаковый тип"<<'\n';
    uint32_t a_1 = UINT32_MAX;
    std::cout << "UINT32_MAX = " << a_1 <<'\n';
    uint32_t result_1 = a_1 + 2;
    std::cout << "UINT32_MAX + 2 = " << result_1<<'\n'<<'\n';


    std::cout << "в битовом виде"<<'\n'<<" ";

    print_bits(UINT32_MAX);
    std::cout << '\n'<<"+"<< '\n'<< " ";
    print_bits(2);
    std::cout <<'\n'<< "----------------------------------"<<'\n'<<" ";
    print_bits(UINT32_MAX+2);
    std::cout <<'\n'<< '\n';



    std::cout << "знаковый тип "<<'\n';
    int32_t b_1 = INT32_MAX;
    std::cout << "INT32_MAX = " << b_1 << '\n';
    int32_t result_2 = b_1 + 2;
    std::cout << "INT32_MAX + 2 = " << result_2 << '\n'<<'\n';

    std::cout << "в битовом виде"<<'\n'<<" ";

    print_bits(INT32_MAX);
    std::cout << '\n'<<"+"<< '\n'<< " ";
    print_bits(2);
    std::cout <<'\n'<< "----------------------------------"<<'\n'<<" ";
    print_bits(INT32_MAX+2);
    std::cout <<'\n'<< '\n';



    return 0;
}
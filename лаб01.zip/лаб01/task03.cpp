#include <iostream>
#include <iomanip>




int main() {
    std::cout << std::setprecision(12);

    std::cout << '\n'<<"1) представление чисел "<<'\n';
    float a = 10.25f;
    float b = 7.1f;

    std::cout << "10.25f = " << a << "\n";
    std::cout << "7.1f  = " << b << "\n";




    float summ = a + b;
    std::cout << "10.25f + 7.1f = " << summ << " (без особенностей языка было бы 17.35)\n\n";


    std::cout << "2) нарушение ассоциативности "<<'\n';
    float x = 1.1f;
    float y = 2.9f;
    float z = 3.3f;

    float res1 = (x + y) + z;
    float res2 = x + (y + z);

    std::cout << "(1.1f + 2.9f) + 3.3f = " << res1 << "\n";
    std::cout << "1.1f + (2.9f + 3.3f) = " << res2 << "\n\n";

    std::cout << "3) сравнение на равенство вещ чисел " <<'\n';
    float c = 1.1f + 0.2f;
    float d = 1.3f;

    std::cout << "1.1f + 0.2f = " << c << "\n";
    std::cout << "1.3f = " << d << "\n";
    std::cout << "1.1f + 0.2f  == 1.3f " << (c == d ? " строгое равенство выполнено" : " строгое равенство не выполнено") << "\n";

    return 0;
}
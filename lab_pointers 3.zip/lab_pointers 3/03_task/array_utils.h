#ifndef LAB_POINTERS_ARRAY_UTILS_H
#define LAB_POINTERS_ARRAY_UTILS_H

#pragma once
void fillArray(int* arr, int size);

#endif


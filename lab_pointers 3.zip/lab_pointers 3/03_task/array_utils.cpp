#include "array_utils.h"

void fillArray(int* arr, int size) {
    for (int i = 0; i < size; ++i) {
        arr[i] = (i+1) * 7;
    }
}
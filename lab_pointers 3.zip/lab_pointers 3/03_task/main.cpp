#include <iomanip>
#include <iostream>
#include "array_utils.h"

void printRow(int i, int value, int* addr1, int* addr2, int diff) {
    std::cout << std::setw(2) << i << " | "
              << std::setw(8) << value << " | "
              << std::setw(16) << addr1 << " | "
              << std::setw(16) << addr2 << " | "
              << std::setw(8) << (diff == -1 ? "-" : std::to_string(diff)) << '\n';
}



int main() {


    int staticArr[5];
    int* dynamicArr = new int[5];

    fillArray(staticArr, 5);
    fillArray(dynamicArr, 5);


    std::cout << "Статический массив"<<'\n';
    std::cout << "i  | Значение | &arr[i]          | (arr + i)        | Разница"<<'\n';
    std::cout << "---|----------|------------------|------------------|-----------"<<'\n';
    for (int i = 0; i < 5; i++) {
        int diff = (i == 0) ? -1 : (reinterpret_cast<char*>(&staticArr[i]) - reinterpret_cast<char*>(&staticArr[i-1]));
        printRow(i, staticArr[i], &staticArr[i], staticArr + i, diff);
    }
    std::cout << '\n';


    std::cout << "Динамический массив"<<'\n';
    std::cout << "i  | Значение | &arr[i]          | (arr + i)        | Разница"<<'\n';
    std::cout << "---|----------|------------------|------------------|-----------"<<'\n';
    for (int i = 0; i < 5; i++) {
        int diff = (i == 0) ? -1 : (reinterpret_cast<char*>(&dynamicArr[i]) - reinterpret_cast<char*>(&dynamicArr[i-1]));
        printRow(i, dynamicArr[i], &dynamicArr[i], dynamicArr + i, diff);
    }
    std::cout << '\n';
    delete[] dynamicArr;

    std::cout << '\n'<<" sizeof(staticArr) = "<< sizeof(staticArr) << " байт "<<'\n';
    std::cout << '\n'<<" sizeof(dynamicArr) =  "<< sizeof(dynamicArr) << " байт" <<'\n';

    return 0;
}

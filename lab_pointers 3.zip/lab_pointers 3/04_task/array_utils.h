#ifndef LAB_POINTERS_ARRAY_UTILS_H
#define LAB_POINTERS_ARRAY_UTILS_H

#pragma once

void modifyElementsOnly(int* arr, int size);
void reallocateArray(int*& arr, int& size);
void fakeByValue(int* arr);

#endif
#include <iostream>
#include <string>
#include "array_utils.h"

void printArray(int* arr, int size, const std::string& label) {
    std::cout << label << " [";
    for (int i = 0; i < size; ++i) {
        std::cout << arr[i];
        if (i < size - 1) std::cout << ", ";
    }
    std::cout << "]"<<'\n';
}

int main() {
    int size = 3;
    int* data = new int[3]{1, 2, 3};

    std::cout << "Адрес: " << data << '\n';
    printArray(data, size, "Содержимое");

    modifyElementsOnly(data, size);
    printArray(data, size, "После modifyElementsOnly");

    fakeByValue(data);
    std::cout << "После fakeByValue  " << data << '\n';
    printArray(data, size, "Содержимое(массив не изменился)");

    reallocateArray(data, size);
    std::cout << "Новый адрес: " << data << '\n';
    printArray(data, size, "Содержимое:");

    delete[] data;
    return 0;
}
#include "array_utils.h"

void modifyElementsOnly(int* arr, int size) {
    for (int i = 0; i < size; ++i) {
        arr[i] *= 2;
    }
}

void reallocateArray(int*& arr, int& size) {
    int* temp = new int[size * 2];
    for (int i = 0; i < size; ++i) {
        temp[i] = arr[i];
    }
    delete[] arr;
    arr = temp;
    size *= 2;
}

void fakeByValue(int* arr) {
    arr = nullptr;
}
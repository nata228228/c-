#include "const_utils.h"
#include <iostream>

void printValue(const int* ptr) {
    std::cout << "Значение: " << *ptr << '\n';
}

void printValueRef(const int& value) {
    std::cout << "Значение: " << value << '\n';
}

void tryModify(const int* ptr) {
    //*ptr = 100; //read-only variable is not assignable
}

void setValue(int* ptr, int newValue) {
    *ptr = newValue;
}
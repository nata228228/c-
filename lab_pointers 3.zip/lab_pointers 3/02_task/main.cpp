#include <iostream>
#include "const_utils.h"

int main() {
    int x = 42;

    std::cout << "Проверяем функции printValue и printValueRef"<<'\n';
    printValue(&x);
    printValueRef(x);

    setValue(&x, 100);

    const int* p1 = &x;
    tryModify(p1);
    //*p1 = 50; //read-only variable is not assignable

    int y = 200;
    int* const p2 = &y;
    //p2 = &x; //cannot assign to variable 'p2' with const-qualified type 'int *const'
    std::cout <<'\n'<<"Работаем с п 5: y = "<< y << '\n';
    *p2 = 300;
    std::cout << "Выводим новое значение у = " << y << '\n';


    return 0;
}
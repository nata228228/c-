#ifndef LAB_POINTERS_CONST_UTILS_H
#define LAB_POINTERS_CONST_UTILS_H

#pragma once
void printValue(const int* ptr);
void printValueRef(const int& value);
void tryModify(const int* ptr);
void setValue(int* ptr, int newValue);

#endif
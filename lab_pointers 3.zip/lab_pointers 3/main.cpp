#include <iostream>

int main() {
    std::cout << "Просто есть" << std::endl;
    return 0;
}
#include <iostream>
#include "matrix_utils.h"


int main() {
    int rows = 3;
    int columns = 4;
    int** matrix = createMatrix(rows, columns);

    fillMatrix(matrix, rows, columns);

    std::cout << "матрица 3x4:" << '\n';
    printMatrix(matrix, rows, columns);

    resizeMatrix(matrix, rows, columns, 5, 6);

    std::cout << '\n'<<"изменим размер на 5x6:" << '\n';
    printMatrix(matrix, rows, columns);

    freeMatrix(matrix, rows);
    return 0;
}
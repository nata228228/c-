#include "matrix_utils.h"
#include <algorithm>
#include <iostream>

int** createMatrix(int rows, int cols) {
    int** matrix = new int*[rows];
    for (int i = 0; i < rows; ++i) {
        matrix[i] = new int[cols]();
    }
    return matrix;
}

void fillMatrix(int** matrix, int rows, int cols) {
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            matrix[i][j] = i * j;
        }
    }
}

void printMatrix(int** matrix, int rows, int cols) {
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            std::cout << matrix[i][j] << " ";
        }
        std::cout << '\n';
    }
}

void freeMatrix(int** matrix, int rows) {
    for (int i = 0; i < rows; ++i) {
        delete[] matrix[i];
    }
    delete[] matrix;
}

void resizeMatrix(int**& matrix, int& rows, int& cols, int newRows, int newCols) {
    int** newMatrix = new int*[newRows];
    int minRows = std::min(rows, newRows);
    int minCols = std::min(cols, newCols);

    for (int i = 0; i < newRows; ++i) {
        newMatrix[i] = new int[newCols]();

        if (i < minRows) {
            for (int j = 0; j < minCols; ++j) {
                newMatrix[i][j] = matrix[i][j];
            }
        }
    }

    freeMatrix(matrix, rows);

    matrix = newMatrix;
    rows = newRows;
    cols = newCols;
}
#include "modifiers.h"
#include <iostream>

void modifyByValue(int x) {
    std::cout<<"Адрес x: " <<&x<<", значение: "<<x<<'\n';
    x=999;
    std::cout<< "После изменения(внутри функции): х = " <<x<<'\n';
}


void modifyByPointer(int* x) {

    std::cout<<"Адрес x: " <<x<<", значение: "<<*x<<'\n';
    *x=999;
    std::cout<< "После изменения(внутри функции): х = " <<*x<<'\n';
}

void modifyByReference(int& x) {

    std::cout<<"Адрес x: " <<&x<<", значение: "<<x<<'\n';
    x=999;
    std::cout<< "После изменения(внутри функции): х = " <<x<<'\n';
}


#ifndef LAB_POINTERS_MODIFIERS_H
#define LAB_POINTERS_MODIFIERS_H




#pragma once

void modifyByValue(int x);

void modifyByPointer(int* x);

void modifyByReference(int& x);

#endif

#include <iostream>
#include "modifiers.h"

void demonstrateBasicDifferences(){
    int a = 10;
    std::cout << "Вызов modifyByValue(a):"<<'\n';
    std::cout <<"До вызова: a = " << a << ", адрес a: " << &a << '\n';
    std::cout << "Внутри modifyByValue(a):"<<'\n';
    modifyByValue(a);
    std::cout << "После вызова: a = " << a << '\n'<<'\n';

    std::cout << "Вызов modifyByPointer(&a):"<<'\n';
    std::cout <<"До вызова: a = " << a << ", адрес a: " << &a << '\n';
    std::cout << "Внутри modifyByPointer(&a):"<<'\n';
    modifyByPointer(&a);
    std::cout << "После вызова: a = " << a << '\n'<<'\n';

    std::cout << "Вызов modifyByReference(a):"<<'\n';
    std::cout <<"До вызова: a = " << a << ", адрес a: " << &a << '\n';
    std::cout << "Внутри modifyByReference(a):"<<'\n';
    modifyByReference(a);
    std::cout << "После вызова: a = " << a << '\n';
}

int main() {
    demonstrateBasicDifferences();
    return 0;
}
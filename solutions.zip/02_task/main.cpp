#include "spdlog/spdlog.h"
#include "spdlog/sinks/basic_file_sink.h"
#include "circle.h"
#include "rectangle.h"
#include "figure.h"
#include <vector>

int main() {
    auto logger = spdlog::basic_logger_mt("task02_logger", "../../logs/task02.log");
    logger->set_pattern("%Y-%m-%d %H:%M:%S.%e [%l] %v");
    spdlog::set_default_logger(logger);

    spdlog::info(" Массив указателей ");
    std::vector<Figure*> figures;
    figures.push_back(new Circle(2.0));
    figures.push_back(new Rectangle(3.0, 4.0));

    for (size_t i = 0; i < figures.size(); ++i) {
        spdlog::info("поэлементно ", i);
        figures[i]->area();
        figures[i]->perimetr();
        figures[i]->info();
    }
    for (auto fig : figures) {
        delete fig;
    }
    //
    // spdlog::info(" Массив объектов (срезка) ");
    // Figure figure_array[2];
    //

    return 0;
}
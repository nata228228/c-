#include "spdlog/spdlog.h"
#include "spdlog/sinks/basic_file_sink.h"
#include "circle.h"
#include "rectangle.h"
#include "figure.h"
#include "iostream"

int main() {
    auto logger = spdlog::basic_logger_mt("task01_logger", "../../logs/task01.log");
    logger->set_pattern("%Y-%m-%d %H:%M:%S.%e [%l] %v");
    spdlog::set_default_logger(logger);
    logger->set_level(spdlog::level::debug);
    logger->flush_on(spdlog::level::debug);


    spdlog::info(" Circle ");
    Circle c(5.0);
    c.area();
    c.perimetr();
    c.info();

    spdlog::info(" Rectangle ");
    Rectangle r(2.0, 4.0);
    r.area();
    r.perimetr();
    r.info();

    spdlog::info(" Figure (Circle) ");
    Figure* ptr_c = new Circle(3.0);
    ptr_c->area();
    ptr_c->perimetr();
    ptr_c->info();
    delete ptr_c;

    spdlog::info(" Figure (Rectangle) ");
    Figure* ptr_r = new Rectangle(3.0, 5.0);
    ptr_r->area();
    ptr_r->perimetr();
    ptr_r->info();
    delete ptr_r;

    return 0;
}
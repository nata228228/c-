#include "spdlog/spdlog.h"
#include "spdlog/sinks/basic_file_sink.h"
#include "circle.h"
#include "rectangle.h"
#include <vector>

int main() {
    auto logger = spdlog::basic_logger_mt("task03_logger", "../../logs/task03.log");
    logger->set_pattern("%Y-%m-%d %H:%M:%S.%e [%l] %v");
    spdlog::set_default_logger(logger);
    Figure* ptr_c = new Circle(3.0);
    ptr_c->area();
    ptr_c->perimetr();
    ptr_c->info();
    delete ptr_c;

    spdlog::info(" Массив указателей ");
    std::vector<Figure*> figures;
    figures.push_back(new Circle(2.0));
    figures.push_back(new Rectangle(3.0, 4.0));

    for (auto f : figures) {
        f->info();
    }
    for (auto f : figures) {
        delete f;
    }
    // spdlog::info(" Массив объектов (срезка) ");
    // Figure figure_array[2];
    // figure_array[0] = Circle(5.0);
    // figure_array[1] = Rectangle(2.0, 3.0);
    // for (int i = 0; i < 2; ++i) {
    //     figure_array[i].info();
    // }
    return 0;
}
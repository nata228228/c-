#include "spdlog/spdlog.h"
#include "spdlog/sinks/basic_file_sink.h"
#include "figure.h"
#include "figure_non_virtual.h"
#include <iostream>

int main() {
    auto logger = spdlog::basic_logger_mt("task04_logger", "../../logs/task04.log");
    logger->set_pattern("%Y-%m-%d %H:%M:%S.%e [%l] %v");
    spdlog::set_default_logger(logger);

    spdlog::info("размер Figure (с) {}", sizeof(Figure));
    spdlog::info("Размер FigureNonVirtual (без) {} ", sizeof(FigureNonVirtual));
    //
    // spdlog::info("объект Figure ");
    // Figure fig;

    spdlog::info(" Создание объекта FigureNonVirtual ");
    FigureNonVirtual figNonVirtual;

    std::cout << "Figure (с virtual):           " << sizeof(Figure)  << std::endl;
    std::cout << "FigureNonVirtual (без virtual): " << sizeof(FigureNonVirtual) <<std::endl;
    return 0;
}